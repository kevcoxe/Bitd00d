 Q.Sprite.extend("Fire", {
  init: function(p) {
    this._super(p, { sheet: 'fire' });
  }
});

Q.Sprite.extend("Water", {
  init: function(p) {
    this._super(p, { sheet: 'water' });
  }
});
Q.Sprite.extend("Earth", {
  init: function(p) {
    this._super(p, { sheet: 'earth' });
  }
});
Q.Sprite.extend("Wind", {
  init: function(p) {
    this._super(p, { sheet: 'wind' });
  }
});
Q.Sprite.extend("Clear", {
  init: function(p) {
    this._super(p, { sheet: 'clear' });
  }
});

Q.Sprite.extend("Tower", {
  init: function(p) {
    this._super(p, { sheet: 'tower' });
  }
});

Q.Sprite.extend("Heart", {
  init: function(p) {
   this._super(p, { sheet: 'heart' });

  }
});

Q.Sprite.extend("Shield", {
  init: function(p) {
   this._super(p, { sheet: 'shield' });

  }
});

Q.Sprite.extend("Coin", {
  init: function(p) {
   this._super(p, { sheet: 'coin' });

  }
});
